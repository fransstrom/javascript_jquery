function nameLabel() {
    var namn;
    name = document.getElementById('name').value;
    document.getElementById('title').innerHTML = "Välkommen " + name + "!";
}

number = Math.floor(Math.random() * 10 + 1);




